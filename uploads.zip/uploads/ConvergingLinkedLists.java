public class ConvergingLinkedLists {
    ///****************************************
    //Assume that we have two singly linked lists of unknown length (i.e., number of nodes in each list).
    // The lengths of the lists can be different (e.g., one list can have 8 notes and the other 5 nodes).
    // The two lists converge into the first node of a singly linked list. 
    //Below is the linkedlist implementation
    //*********************************************
    public static class SinglyLinkedList{
            Node head; 
            class Node {
                String data;
                Node next;
            Node(String value)
            {
            data = value;
            next = null;
            }
            }
    public SinglyLinkedList add(SinglyLinkedList l, String data)
    {
        Node start= new Node(data);
        start.next = null;
        
        if (l.head == null) {
            l.head = start;
        }
        else {
            Node last = l.head;
            while (last.next != null) {
                last = last.next;
            }
            last.next = start;
        }
        return l;
    }
    public String getAddress(SinglyLinkedList l,String val)
    {
        Node start = l.head;
        String address="";
        while (start != null) {
            if(start.data.equals(val)){
            address=start.toString();
            }
            start = start.next;
        }
        return address;
    }
       public String[] getItemArray(SinglyLinkedList l)
    {
        Node start = l.head;
        String address="";
        int count=0;
        int increment=0;
        while (start != null) {
            count+=1;
            start = start.next;
        }
        String[] store=new String[count];
        while (start != null) {
            if(increment!=count){
                store[increment]=start.data;
            }
            increment+=1;
            start = start.next;
        }
        
        return store;
    }
    }
    //*********************************************************8
    //Creating the first stack
    private class FirstStackNode {
        String data;
        FirstStackNode address; 
    }
    FirstStackNode FirstHead;
    //Creating the second stack
    private class SecondStackNode {
        String data;
        SecondStackNode address; 
    }
    SecondStackNode SecondHead;

    
    
    ConvergingLinkedLists()
    {
        this.FirstHead = null;
        this.SecondHead = null;
    }
    
    //The add item to first stack head method
    public void addToFirstHead(String val) 
    {
        FirstStackNode start = new FirstStackNode();
        if (start== null) {
            return;
        }
        start.data = val;
        start.address = FirstHead;
        FirstHead = start;
    }
    //The add item to first stack head method
    public void addToSecondHead(String val) 
    {
        SecondStackNode start = new SecondStackNode();
        if (start== null) {
            return;
        }
        start.data = val;
        start.address = SecondHead;
        SecondHead = start;
    }
    //The remove item from Firsthead method
    public void removeFromFirstHead() 
    {
        if (FirstHead== null) {
            return;
        }
        FirstHead = (FirstHead).address;
    }
     //The remove item from Secondthead method
    public void removeFromSecondHead() 
    {
        if (SecondHead== null) {
            return;
        }
        SecondHead = (SecondHead).address;
    }
    
    public String traverse(SinglyLinkedList first, SinglyLinkedList second){
        String[] First=first.getItemArray(first);
        String[] Second=second.getItemArray(second);
        
        String temp="";
        
        ConvergingLinkedLists converging=new ConvergingLinkedLists();
        
        //Traverse the first list and push all the node addresses onto the first stack
        for(String val: First){
            converging.addToFirstHead(first.getAddress(first, val));
        }
        
        //Traverse the second list and push all the node addresses onto the second stack
        for(String val: Second){
             converging.addToSecondHead(second.getAddress(second, val));
        }
        
        //Now both stacks contain the node address of the corresponding lists
       // Now compare the top node address of both stacks.
       while(true){
           if(converging.FirstHead.data.equals(converging.SecondHead.data)){
              temp=FirstHead.data;
           }else{
              break;
              
           }
           
       }
       System.out.println("Linked Lists Have Converged");
       return temp;
    }
    
 
    public static void main(String[] args) {
       SinglyLinkedList test=new SinglyLinkedList();
       test.add(test,"1");
       test.add(test,"2");
       test.add(test,"3");
       test.add(test,"4");
       test.add(test,"5");
       test.add(test,"6");
       test.add(test,"7");
       
       SinglyLinkedList test2=new SinglyLinkedList();
       test2.add(test2,"8");
       test2.add(test2,"9");
       test2.add(test2,"10");
       test2.add(test2,"11");
       test2.add(test2,"12");
       test2.add(test2,"13");
       
       ConvergingLinkedLists convergetest=new ConvergingLinkedLists();
       String output=convergetest.traverse(test, test2);
       
       
       
     
    }
    
}
